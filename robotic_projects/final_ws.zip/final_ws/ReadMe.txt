# EE 451 Project Final 
# Fatih Mecidiye
# Celal Tayyib Ciminli

1.1 Prerequisites:

	1. Melodic/Noetic Distribution of ROS
	2. Moveit API (Can be installed using the following commands)

	sudo apt-get install ros-<distribution>-moveit
	sudo apt-get install ros-<distribution>-moveit-visual-tools

	3. if the following error occurs:
	Resource not found: moveit_resources_prbt_moveit_config
	moveit_resources_prbt_moveit_config is missing 
	this pkg can be installed with the following command
	sudo apt install ros-<distribution>-moveit-resources-prbt-moveit-config

1.2 Creating the work space and copying the project files.
	
	1. The project files (robot_config & planning) should be copied to an existing workspace src folder
	or alternatively the home directory a workspace can be initialized with the following command:
	
	mkdir -p final_ws/src/
	
	2. The project can be built by running the following:
	
	cd ~/final_ws && catkin_make
	
1.3 Running the project

	1. Note: The setup.bash file should be sourced in each terminal with
	
	cd ~/final_ws
	source devel/setup.bash

	2. In the first shell, the params.yaml or params2.yaml is run by following command
	roslaunch planning read_params.launch	
	
	3. After this the robot model can be opened in Rviz using the following command
	
	roslaunch robot_config demo.launch
	
	4. In a third shell the following command runs the c++ file that controls the robot
	
	roslaunch planning robot_move.launch 2>/dev/null

	


	





