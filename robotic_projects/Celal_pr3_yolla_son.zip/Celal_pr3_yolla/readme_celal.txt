To run our code, we first need to go to the cd ws_moveit workspace.
- Then we have to run it with the catkin build command.
-After that, we enter the command source devel/setup.bash into the terminal
- Finally, we open our robot in Rviz with the origins_config demo.launch command.

-- The next step is to run our C++ code.
-- We should definitely do this after we have source devel/setup.bash in our workspace.
After entering the command --roslaunch celal_robot celal_robot.launch, the operations are completed in the terminal. At this point, our matrix values are written in the Jacobian : part. Here we read the first incoming jacobian matrix values.


